﻿using BatchCoreService;
using System;

namespace GateWay
{

}
