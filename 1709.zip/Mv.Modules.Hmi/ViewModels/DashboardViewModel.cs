﻿using Mv.Ui.Mvvm;
using System;
using System.Collections.Generic;
using System.Text;
using Unity;

namespace Mv.Modules.Hmi.ViewModels
{
    public class DashboardViewModel : ViewModelBase
    {
        public DashboardViewModel(IUnityContainer container) : base(container)
        {
        }
    }
}
