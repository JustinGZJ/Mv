﻿namespace Mv.Shell.Views.AppStore
{
    /// <summary>
    /// Interaction logic for AppStoreComponent.xaml
    /// </summary>
    public partial class AppStoreComponent
    {
        public AppStoreComponent()
        {
            InitializeComponent();
        }
    }
}
