﻿namespace Mv.Shell.Views.Authentication
{
    /// <summary>
    /// Interaction logic for SignUpView.xaml
    /// </summary>
    public partial class SignUpView
    {
        public SignUpView()
        {
            InitializeComponent();
        }

      
    }
}
