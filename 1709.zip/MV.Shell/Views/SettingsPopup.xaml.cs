﻿namespace Mv.Shell.Views
{
    /// <summary>
    /// Interaction logic for SettingsPopup.xaml
    /// </summary>
    public partial class SettingsPopup
    {
        public SettingsPopup()
        {
            InitializeComponent();
        }
    }
}
