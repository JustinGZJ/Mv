﻿namespace Mv.Shell.Views.Dialogs
{
    /// <summary>
    /// Interaction logic for ProfileDialog.xaml
    /// </summary>
    public partial class ProfileDialog
    {
        public ProfileDialog()
        {
            InitializeComponent();
        }
    }
}
