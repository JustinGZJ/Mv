﻿namespace Mv.Shell.Views.Dialogs
{
    /// <summary>
    /// Interaction logic for SettingsDialog.xaml
    /// </summary>
    public partial class SettingsDialog
    {
        public SettingsDialog()
        {
            InitializeComponent();
        }
    }
}
