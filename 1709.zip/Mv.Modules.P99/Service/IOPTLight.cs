﻿namespace Mv.Modules.P99
{
    public interface IOPTLight
    {
        short GetCurrent(int index);
    }
}