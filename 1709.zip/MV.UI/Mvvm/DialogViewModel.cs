﻿using System.Windows.Input;

namespace Mv.Ui.Mvvm
{
    public class DialogViewModel
    {
        public ICommand CloseCommand { get; set; }
    }
}
