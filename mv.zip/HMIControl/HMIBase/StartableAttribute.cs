﻿using System;

namespace HMIControl
{

    [AttributeUsageAttribute(AttributeTargets.Class, Inherited = false)]
    [Serializable]
    public class StartableAttribute : Attribute
    {
    }
}




