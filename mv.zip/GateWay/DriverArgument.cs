﻿namespace BatchCoreService
{
    public class DriverArgument
    {
        public int Id { get; set; }
        public int DriverID { get; set; }
        public string PropertyName { get; set; }
        public string PropertyValue { get; set; }
    }
}
