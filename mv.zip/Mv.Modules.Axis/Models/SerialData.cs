using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Xml;

namespace MotionWrapper
{
    public class SerialData
    {
        public string sn = "";
        public string macSN = "";
        public string startTime = "";
    }
}
