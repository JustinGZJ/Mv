﻿namespace MotionWrapper
{
    /// <summary>
    /// 凸轮运行状态
    /// </summary>
    public class CCamStatus
    {
        public int line = 0;//当前执行得段号
        public bool running = false;//当前正在运行
    }
}
