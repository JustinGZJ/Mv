﻿namespace MotionWrapper
{
    public class CPauseType
    {
        public EPauseType pauseType = new EPauseType();
        public int restartStep = -1;//重启的段号
    }
}
