﻿namespace MotionWrapper
{
    public enum EPauseType
    {
        NONE =0,NEEDSTOP=1
    }
}
