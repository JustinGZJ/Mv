﻿using System.Windows.Controls;

namespace Mv.Modules.Axis.Views
{
    /// <summary>
    /// Interaction logic for P2PData
    /// </summary>
    public partial class P2PData : UserControl
    {
        public P2PData()
        {
            InitializeComponent();
        }
    }
}
