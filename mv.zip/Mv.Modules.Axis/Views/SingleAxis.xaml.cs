﻿  using System.Windows.Controls;

namespace Mv.Modules.Axis.Views
{
    /// <summary>
    /// Interaction logic for SingleAxis
    /// </summary>
    public partial class SingleAxis : UserControl
    {
        public SingleAxis()
        {
            InitializeComponent();
        }
    }
}
