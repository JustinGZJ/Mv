﻿using System.Windows.Controls;

namespace Mv.Modules.Axis.Views
{
    /// <summary>
    /// Interaction logic for InOut
    /// </summary>
    public partial class InOut : UserControl
    {
        public InOut()
        {
            InitializeComponent();
        }
    }
}
