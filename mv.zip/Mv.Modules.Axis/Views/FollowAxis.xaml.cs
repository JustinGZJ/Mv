﻿using System.Windows.Controls;

namespace Mv.Modules.Axis.Views
{
    /// <summary>
    /// Interaction logic for FollowAxis
    /// </summary>
    public partial class FollowAxis : UserControl
    {
        public FollowAxis()
        {
            InitializeComponent();
        }
    }
}
