﻿using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mv.Modules.Axis.ViewModels
{
    public class FollowAxisViewModel : BindableBase
    {
        public FollowAxisViewModel()
        {

        }
    }
}
