﻿
namespace Mv.Ui.Core.Modularity
{
    public class RemoteRef
    {
        public string RemotePath { get; set; }

        public string LocalPath { get; set; }
    }
}
