﻿using Mv.Ui.Mvvm;
using Unity;

namespace Mv.Shell.ViewModels.AppStore
{
    public class AppStoreComponentViewModel : ViewModelBase
    {
        public AppStoreComponentViewModel(IUnityContainer container) : base(container)
        {
        }
    }
}
