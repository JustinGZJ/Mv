﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Input;
using Mv.Shell.Constants;
using Mv.Ui.Core;
using Mv.Ui.Mvvm;
using Unity;

namespace Mv.Shell.ViewModels.Dialogs
{
    public class AboutDialogViewModel : ViewModelBase
    {


        public AboutDialogViewModel(IUnityContainer container) : base(container)
        {
    
        }

    }
}
