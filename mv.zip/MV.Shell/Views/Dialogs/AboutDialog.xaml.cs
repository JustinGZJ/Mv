﻿namespace Mv.Shell.Views.Dialogs
{
    /// <summary>
    /// Interaction logic for AboutDialog.xaml
    /// </summary>
    public partial class AboutDialog
    {  
        public AboutDialog()
        {
            InitializeComponent();
        }
    }
}
