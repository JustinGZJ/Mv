﻿namespace Mv.Shell.Views.Authentication
{
    /// <summary>
    /// Interaction logic for SignInView.xaml
    /// </summary>
    public partial class SignInView
    {
        public SignInView()
        {
            InitializeComponent();
        }
    }
}
