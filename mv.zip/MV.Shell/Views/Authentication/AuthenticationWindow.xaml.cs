﻿namespace Mv.Shell.Views.Authentication
{
    /// <summary>
    /// Interaction logic for AuthenticationWindow.xaml
    /// </summary>
    public partial class AuthenticationWindow
    {
        public AuthenticationWindow()
        {
            
            InitializeComponent();
        }
    }
}
