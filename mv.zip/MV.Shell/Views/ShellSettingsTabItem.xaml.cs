﻿namespace Mv.Shell.Views
{
    /// <summary>
    /// Interaction logic for ShellSettingsTabItem.xaml
    /// </summary>
    public partial class ShellSettingsTabItem
    {
        public ShellSettingsTabItem()
        {
            InitializeComponent();
        }
    }
}
