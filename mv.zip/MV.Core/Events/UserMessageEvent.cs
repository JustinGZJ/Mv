﻿using Prism.Events;

namespace MV.Core.Events
{

    public class UserMessageEvent : PubSubEvent<UserMessage>
    {

    }
}
