﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MV.Core.Interfaces
{
    public interface IMainTab
    {
        public string DisplayName { get; }
        public object PackIconKind { get; }
    }
}
